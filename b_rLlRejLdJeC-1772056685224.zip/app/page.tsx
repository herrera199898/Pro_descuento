import { ExportForm } from "@/components/export-form"

export default function Page() {
  return <ExportForm />
}
